#include <windows.h>
#include <string>
#include <iostream>
#include <curl/curl.h> // Asegúrate de tener libcurl instalada
#include <gdiplus.h>   // Para manejar imágenes
#include <nlohmann/json.hpp> // Incluir la biblioteca JSON
#pragma comment(lib, "gdiplus.lib")

// Prototipo del procedimiento de la ventana
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

// Función para manejar la respuesta de la API
size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

// Función para obtener la URL de la imagen usando la API de Unsplash
std::string GetImageUrl(const std::string& word) {
    CURL* curl;
    CURLcode res;
    std::string readBuffer;

    std::string url = "https://api.unsplash.com/photos/random?query=" + word + "J2fTfSt990poKbSQLc-bBSUIqBIBhvaHOEBeXwau6C0"; // Cambia esto por tu clave de acceso

    curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
        res = curl_easy_perform(curl);
        curl_easy_cleanup(curl);
    }

    // Parsear el JSON
    auto jsonResponse = nlohmann::json::parse(readBuffer);
    std::string imageUrl = jsonResponse["urls"]["regular"]; // Obtén la URL de la imagen

    return imageUrl; // Retorna la URL de la imagen obtenida
}

// Función para cargar y mostrar la imagen
void ShowImage(HDC hdc, const std::string& imageUrl) {
    // Convertir std::string a std::wstring
    std::wstring wImageUrl(imageUrl.begin(), imageUrl.end());
    
    // Cargar la imagen
    Gdiplus::Image image(wImageUrl.c_str());
    Gdiplus::Graphics graphics(hdc);
    graphics.DrawImage(&image, 10, 100, image.GetWidth(), image.GetHeight());
}

// Función principal
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nShowCmd) {
    Gdiplus::GdiplusStartupInput gdiplusStartupInput;
    ULONG_PTR gdiplusToken;
    Gdiplus::GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, nullptr);

    const char CLASS_NAME[] = "Sample Window Class";

    // Registro de la clase de ventana
    WNDCLASS wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;

    RegisterClass(&wc);

    // Crear la ventana
    HWND hwnd = CreateWindowEx(
        0, CLASS_NAME, "Traductor con Imagen", WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
        NULL, NULL, hInstance, NULL
    );

    if (hwnd == NULL) {
        return 0; // Error al crear la ventana
    }

    ShowWindow(hwnd, nShowCmd);

    // Bucle de mensajes
    MSG msg = {};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    Gdiplus::GdiplusShutdown(gdiplusToken);
    return 0;
}

// Procedimiento de la ventana
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    static std::string inputWord = "dog"; // Palabra por defecto
    static std::string imageUrl; // URL de la imagen

    switch (uMsg) {
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);

            // Dibujar texto
            TextOut(hdc, 10, 10, "Ingrese una palabra:", 22);
            TextOut(hdc, 10, 30, inputWord.c_str(), inputWord.length());
            TextOut(hdc, 10, 50, "Imagen:", 7);

            // Mostrar la imagen
            if (!imageUrl.empty()) {
                ShowImage(hdc, imageUrl);
            }

            EndPaint(hwnd, &ps);
        } break;

        case WM_KEYDOWN:
            if (wParam == VK_RETURN) {
                imageUrl = GetImageUrl(inputWord);
                InvalidateRect(hwnd, NULL, TRUE); // Redibuja la ventana
            }
            break;

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;

        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
    return 0;
}