#ifndef PERSONA_H
#define PERSONA_H

#include "ListaDoble.h"
#include "Fecha.h"
#include <string>
using namespace std;

class Persona {
private:
    string nombre1;
    string apellido;
    string cedula;
    int prestamo;

public:
    Persona();
    Persona(string n1, string a, string cedula);
    Persona(string cedula);

    void setNombre1(string n1);
    void setApellido(string a);
    void setCedula(string cedula);
    void setPrestamo(int p);
    

    string getNombre1();
    string getApellido();
    string getCedula();
    int getPrestamo();



    friend std::ostream& operator<<(std::ostream& os, const Persona& p) {

        os << "Persona(Nombre: " << p.nombre1 << ", Apellido: " << p.apellido << ", ID: " << p.cedula << ", Prestamo: " << p.prestamo <<")";
        return os;
    }

    bool operator==(const Persona& other) const {

        return this->cedula == other.cedula; 
    }
};

#endif
