#include "ListaDoble.h"
#include "Validacion.h"
#include "Persona.h"
#include "Fecha.h"
#include "Api.h"
//#include "libharu/hpdf.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <windows.h>

using namespace std;

enum Opciones {
    AGREGAR_PERSONA,
    PEDIR_PRESTAMO,
    MOSTRAR_PRESTAMO,
    GUARDAR_SALIR,
    NUM_OPCIONES
};

void setConsoleColor(WORD color) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
}

void mostrarMenu(int opcion) {
    system("cls");
    const char* opciones[] = {
        "1. Agregar persona.",
        "2. Pedir prestamo.",
        "3. Mostrar personas.",
        "4. Guardar y Salir"
    };

    cout << "******************************" << endl;
    cout << "        Menu de opciones      " << endl;
    cout << "******************************" << endl;
    for (int i = 0; i < NUM_OPCIONES; ++i) {
        if (i == opcion) {
            setConsoleColor(FOREGROUND_GREEN | FOREGROUND_INTENSITY | BACKGROUND_BLUE); // Cambiar color
            cout << " --> " << opciones[i] << "\n";
            setConsoleColor(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE); // Restaurar color
        }
        else {
            cout << "     " << opciones[i] << "\n";
        }
    }
    cout << "******************************" << endl;
}

void guardarInformacionPersonas(ListaDoble<Persona>* lista) {
    ofstream archivo("datos.txt");

    Nodo<Persona>* actual = lista->getCabeza();
    while (actual) {
        archivo << actual->getDato().getNombre1() << " "
                << actual->getDato().getApellido() << " "
                << actual->getDato().getCedula() << " "
                << actual->getDato().getPrestamo() << endl;
        
        archivo << endl;
        actual = actual->getSiguiente();
    }

    archivo.close();
    cout << "Informacion guardada en datos.txt" << endl;
}

void cargarInformacionPersonas(ListaDoble<Persona>* lista) {
    ifstream archivo("datos.txt");
    string nombre1, apellido, cedula;
    int prestamo;

    while (archivo >> nombre1 >> apellido >> cedula >> prestamo) {
        Persona persona(nombre1, apellido, cedula);
        persona.setPrestamo(prestamo);

        lista->Insertar(persona);
    }

    archivo.close();
    cout << "Informacion cargada desde datos.txt" << endl;
}

ListaDoble<Fecha>* generarFechasPago(int diaElegido, int mesElegido, int anioInicial, const vector<Feriado>& feriados) {
    ListaDoble<Fecha>* fechasPago = new ListaDoble<Fecha>();
    int dia = diaElegido;
    int cont = 0;

    while (cont < 6) { 
        // Ajustar día para fin de semana o feriado
        while (esFinDeSemana(dia, mesElegido, anioInicial) || 
               find(feriados.begin(), feriados.end(), Feriado{dia, mesElegido}) != feriados.end()) {
            dia++;
            if (dia > 31) {
                dia = 1;
                mesElegido++;
                if (mesElegido > 12) {
                    mesElegido = 1;
                    anioInicial++;
                }
                break;
            }
        }

        // Validar que el día sea válido para el mes (ej. Febrero)
        if ((mesElegido == 2 && dia > 28) || 
            ((mesElegido == 4 || mesElegido == 6 || mesElegido == 9 || mesElegido == 11) && dia > 30)) {
            continue;
        }

        fechasPago->Insertar(Fecha(dia, mesElegido, anioInicial));
        cout << "Fecha de pago generada: " << dia << "/" << mesElegido << "/" << anioInicial << endl;
        cont++;

        mesElegido++;
        if (mesElegido > 12) {
            mesElegido = 1;
            anioInicial++;
        }
    }

    system("pause");
    return fechasPago;
}


void generarTablaAmortizacionTXT(Persona& persona, ListaDoble<Fecha>* fechasPago) {
    
 
ofstream archivo(persona.getCedula() +"_"+to_string(persona.getPrestamo())+ "_amortizacion.txt");

    if (!archivo) {
        cout << "Error al crear el archivo de amortizacion." << endl;
        return;
    }

    archivo << "Tabla de Amortizacion para: " << persona.getNombre1() << " " << persona.getApellido() << endl;
    archivo << "Cedula: " << persona.getCedula() << endl;
    archivo << "Prestamo: $" << persona.getPrestamo() << endl;
    archivo << "------------------------------------------" << endl;
    archivo << "Cuota | Fecha de Pago  | Monto" << endl;
    archivo << "------------------------------------------" << endl;

    Nodo<Fecha>* actualFecha = fechasPago->getCabeza();
    int cuota = 1;
    double montoPorCuota = persona.getPrestamo() / 6.0;  // Ejemplo: 6 cuotas

    while (actualFecha) {
        archivo << cuota << "     | "
                << actualFecha->getDato().getDia() << "/"
                << actualFecha->getDato().getMes() << "/"
                << actualFecha->getDato().getAnio() << "   | $"
                << montoPorCuota << endl;
        actualFecha = actualFecha->getSiguiente();
        cuota++;
    }

    archivo.close();
    cout << "Tabla de amortizacion guardada en " << persona.getCedula() +"_"+to_string(persona.getPrestamo())+"_amortizacion.txt" << endl;
}

/*void generarTablaAmortizacionPDF(Persona& persona, ListaDoble<Fecha>* fechasPago) {
    // Crear un nuevo documento PDF
    HPDF_Doc pdf = HPDF_New(NULL, NULL);
    if (!pdf) {
        cerr << "Error al crear el documento PDF." << endl;
        return;
    }

    // Agregar una nueva página
    HPDF_Page page = HPDF_AddPage(pdf);
    HPDF_Page_SetSize(page, HPDF_PAGE_SIZE_A4, HPDF_PAGE_PORTRAIT);

    // Configurar la fuente y tamaño
    HPDF_Font font = HPDF_GetFont(pdf, "Helvetica", NULL);
    HPDF_Page_SetFontAndSize(page, font, 12);

    // Título
    HPDF_Page_BeginText(page);
    HPDF_Page_TextOut(page, 50, 800, "Tabla de Amortizacion");
    HPDF_Page_EndText(page);

    // Detalles de la persona
    string nombreCompleto = persona.getNombre1() + " " + persona.getApellido();
    HPDF_Page_BeginText(page);
    HPDF_Page_TextOut(page, 50, 780, ("Nombre: " + nombreCompleto).c_str());
    HPDF_Page_TextOut(page, 50, 760, ("Cédula: " + persona.getCedula()).c_str());
    HPDF_Page_TextOut(page, 50, 740, ("Préstamo: $" + to_string(persona.getPrestamo())).c_str());
    HPDF_Page_EndText(page);

    // Encabezado de la tabla
    HPDF_Page_BeginText(page);
    HPDF_Page_TextOut(page, 50, 720, "Fecha de Pago          Monto a Pagar");
    HPDF_Page_EndText(page);

    // Agregar las fechas de pago a la tabla
    Nodo<Fecha>* actual = fechasPago->getCabeza();
    int y = 700;
    while (actual != nullptr) {
        string fecha = to_string(actual->getDato().getDia()) + "/" +
                       to_string(actual->getDato().getMes()) + "/" +
                       to_string(actual->getDato().getAnio());
        string monto = "$" + to_string(persona.getPrestamo() / 6);  // Por ejemplo, dividir el préstamo en 6 pagos

        HPDF_Page_BeginText(page);
        HPDF_Page_TextOut(page, 50, y, fecha.c_str());
        HPDF_Page_TextOut(page, 200, y, monto.c_str());
        HPDF_Page_EndText(page);

        y -= 20;
        actual = actual->getSiguiente();
    }

    // Guardar el PDF con el nombre basado en la cédula
    string nombreArchivo = persona.getCedula()+"_"+to_string(persona.getPrestamo()) + "_tabla_amortizacion.pdf";
    HPDF_SaveToFile(pdf, nombreArchivo.c_str());

    // Limpiar y liberar el documento PDF
    HPDF_Free(pdf);

    cout << "PDF generado: " << nombreArchivo << endl;
}*/

int main() {
    ListaDoble<Persona>* lista = new ListaDoble<Persona>();
    
    cargarInformacionPersonas(lista);
    vector<Feriado> feriados = obtenerFeriadosDesdeAPI();
    
    int opcion = 0;
    bool continuar = true;

    while (continuar) {
        mostrarMenu(opcion);

        int tecla = _getch();
        switch (tecla) {
        case 72: // Flecha arriba
            opcion = (opcion - 1 + NUM_OPCIONES) % NUM_OPCIONES;
            break;
        case 80: // Flecha abajo
            opcion = (opcion + 1) % NUM_OPCIONES;
            break;
        case 13: // Enter
            switch (opcion) {
                case AGREGAR_PERSONA:{
                    bool igual;
                    string cedula, nombre, apellido;
                    cout << "Ingresar cedula: ";
                    cedula = ingresarCedula();
                    Persona per(cedula);
                    igual = lista->Buscar(per);
                    if(!igual){
                        cout << "Ingresar nombre: ";
                        nombre = ingresarLetra();
                        cout << "Ingresar apellido: ";
                        apellido = ingresarLetra();

                        lista->Insertar(Persona(nombre, apellido, cedula));
                        cout<<"Se inserto correctamente la persona"<<endl;
                        system("pause");
                    }else{
                        cout<<"Ya existe ese numero de cedula"<<endl;
                        system("pause");
                    }
                        
                    break;
                }
                case PEDIR_PRESTAMO:{
                    string cedula;
                    int prestamo, dia, mes;
                    bool encontrado;
                    cout << "Ingrese la cedula: ";
                    cedula = ingresarCedula();
                    Persona per(cedula);
                    encontrado = lista->Buscar(per);
                    if (encontrado) {
                        per = lista->BuscarElemento(per);
                        cout << "Ingrese el monto que desee de prestamo: ";
                        prestamo = ingresarEntero4();
                        per.setPrestamo(prestamo);

                        cout << "Ingrese el dia de cada mes que desee pagar: ";
                        dia = validarDia();
                        cout << "Ingrese el mes que desee pagar: ";
                        mes = validarMes();
                        
                        ListaDoble<Fecha>* fechasPago = generarFechasPago(dia, mes, 2024, feriados);
                        
                        lista->Actualizar(per);
                        
                        generarTablaAmortizacionTXT(per, fechasPago);
                        //generarTablaAmortizacionPDF(per, fechasPago);
                    } else {
                        cout << "Persona no encontrada." << endl;
                        system("pause");
                    }
                    break;
                }
                
                case MOSTRAR_PRESTAMO:{
                    lista->Mostrar();
                    system("pause");
                    break;
                }
                case GUARDAR_SALIR:{
                    guardarInformacionPersonas(lista);
                    continuar = false;
                    break;
                }
            }
        }
    }

    delete lista;
    return 0;
}
