#ifndef FECHA_H
#define FECHA_H

#include <iostream>

class Fecha{
private:
    int dia;
    int mes;
    int anio;
public:
    Fecha();
    Fecha(int dia, int mes, int anio);
    int getDia();
    void setDia(int );
    int getMes();
    void setMes(int );
    int getAnio();
    void setAnio(int );
    void toString();

    friend std::ostream& operator<<(std::ostream& os, const Fecha& f) {
        // Implement output logic here
        // Example: output day, month, year
        os << "Fecha(Day: " << f.dia << ", Month: " << f.mes << ", Year: " << f.anio << ")";
        return os;
    }

    bool operator==(const Fecha& other) const {
        // Implement comparison logic here
        // Example: compare day, month, and year
        return (this->dia == other.dia && this->mes == other.mes && this->anio == other.anio);
    }
};

#endif // FECHA_H