#pragma once

#include <iostream>
#include <string>
#include <vector>
#include "curl/curl.h"
#include "nlohmann/json.hpp"

using json = nlohmann::json;
using namespace std;

size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    ((string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

struct Feriado {
    int dia;
    int mes;

    bool operator==(const Feriado& otro) const {
        return dia == otro.dia && mes == otro.mes;
    }
};

vector<Feriado> obtenerFeriadosDesdeAPI() {
    vector<Feriado> feriados;
    CURL* curl;
    CURLcode res;
    string readBuffer;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, "https://calendarific.com/api/v2/holidays?api_key=CfLKtbz0jNPcbQYIFupXnQ3eMw0Nrs94&country=EC&year=2024");
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);

        res = curl_easy_perform(curl);
        if (res != CURLE_OK) {
            cerr << "curl_easy_perform() falló: " << curl_easy_strerror(res) << endl;
        } else {
            try {
                auto jsonResponse = json::parse(readBuffer);
                if (jsonResponse.contains("response") && jsonResponse["response"].contains("holidays") && jsonResponse["response"]["holidays"].is_array()) {
                    for (const auto& holiday : jsonResponse["response"]["holidays"]) {
                        if (holiday.contains("date") && holiday["date"].contains("datetime")) {
                            auto datetime = holiday["date"]["datetime"];
                            if (datetime.contains("day") && datetime.contains("month")) {
                                Feriado feriado;
                                feriado.dia = datetime["day"].get<int>();
                                feriado.mes = datetime["month"].get<int>();
                                feriados.push_back(feriado);
                            }
                        }
                    }
                } else {
                    cerr << "Estructura JSON inesperada." << endl;
                }
            } catch (const json::exception& e) {
                cerr << "Error al analizar el JSON: " << e.what() << endl;
            }
        }

        curl_easy_cleanup(curl);
    } else {
        cerr << "No se pudo inicializar CURL" << endl;
    }
    curl_global_cleanup();

    return feriados;
}

bool esFeriado(int dia, int mes, const vector<Feriado>& feriados) {
    for (const auto& feriado : feriados) {
        if (feriado.dia == dia && feriado.mes == mes) {
            return true;
        }
    }
    return false;
}

