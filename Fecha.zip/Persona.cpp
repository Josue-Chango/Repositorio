#include "Persona.h"
#include <algorithm> 
#include <cctype>    

Persona::Persona() : nombre1(""), apellido(""), cedula(""), prestamo(0) {}

Persona::Persona(string n1, string a, string c) : nombre1(n1), apellido(a), cedula(c), prestamo(0) {}

Persona::Persona(string c): nombre1(""), apellido(""), cedula(c), prestamo(0) {}

void Persona::setNombre1(string n1) {
    nombre1 = n1;
}

void Persona::setApellido(string a) {
    apellido = a;
}

void Persona::setCedula(string c) {
    cedula = c;
}

string Persona::getCedula() {
    return cedula;
}

string Persona::getNombre1() {
    return nombre1;
}


string Persona::getApellido() {
    return apellido;
}

void Persona::setPrestamo(int p){
    prestamo=p;
}

int Persona::getPrestamo(){
    return prestamo;
}
