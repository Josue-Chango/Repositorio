#include "Fecha.h"

using namespace std;

Fecha::Fecha(): dia(01), mes(01), anio(2000) {}

Fecha::Fecha(int d, int m, int a): dia(d), mes(m), anio(a) {}

void Fecha::setDia(int d){
    dia=d;
}

void Fecha::setMes(int m){
    mes=m;
}

void Fecha::setAnio(int a){
    anio=a;
}

int Fecha::getDia(){
    return dia;
}

int Fecha::getMes(){
    return mes;
}

int Fecha::getAnio(){
    return anio;
}

void Fecha::toString()
{
    cout << dia << "/" << mes << "/" << anio;
}