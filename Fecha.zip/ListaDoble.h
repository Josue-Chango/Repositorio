#ifndef LISTADOBLE_H
#define LISTADOBLE_H

#include <iostream>
using namespace std;

template <typename T>
struct Nodo {
    T dato;
    Nodo* siguiente;
    Nodo* anterior;

    Nodo(T d);
    T getDato();
    Nodo<T>* getSiguiente();
    Nodo<T>* getAnterior();
};

template <typename T>
class ListaDoble {
private:
    Nodo<T>* cabeza;
    Nodo<T>* cola;

public:
    ListaDoble();
    void Insertar(T dato);
    bool Buscar(T dato);
    T BuscarElemento(T dato);
    void Eliminar(T dato);
    void Mostrar();
    Nodo<T>* getCabeza();
    Nodo<T>* getCola();
    void Actualizar(T dato);
};

// Implementación de Nodo
template <typename T>
Nodo<T>::Nodo(T d) : dato(d), siguiente(nullptr), anterior(nullptr) {}

template <typename T>
T Nodo<T>::getDato() {
    return dato;
}

template <typename T>
Nodo<T>* Nodo<T>::getSiguiente() {
    return siguiente;
}

template <typename T>
Nodo<T>* Nodo<T>::getAnterior() {
    return anterior;
}

// Implementación de ListaDoble
template <typename T>
ListaDoble<T>::ListaDoble() : cabeza(nullptr), cola(nullptr) {}

template <typename T>
void ListaDoble<T>::Insertar(T dato) {
    Nodo<T>* nuevo = new Nodo<T>(dato);
    if (!cabeza) {
        cabeza = nuevo;
        cola = nuevo;
    } else {
        cola->siguiente = nuevo;
        nuevo->anterior = cola;
        cola = nuevo;
    }
}

template <typename T>
bool ListaDoble<T>::Buscar(T dato) {
    Nodo<T>* actual = cabeza;
    while (actual) {
        if (actual->dato == dato) {
            return true;
        }
        actual = actual->siguiente;
    }
    return false;
}

template <typename T>
T ListaDoble<T>::BuscarElemento(T dato) {
    Nodo<T>* actual = cabeza;
    while (actual) {
        if (actual->dato == dato) {
            return actual->getDato();
        }
        actual = actual->siguiente;
    }
    throw runtime_error("Elemento no encontrado");
}

template <typename T>
void ListaDoble<T>::Eliminar(T dato) {
    Nodo<T>* actual = cabeza;
    while (actual) {
        if (actual->dato == dato) {
            if (actual->anterior) {
                actual->anterior->siguiente = actual->siguiente;
            } else {
                cabeza = actual->siguiente;
            }
            if (actual->siguiente) {
                actual->siguiente->anterior = actual->anterior;
            } else {
                cola = actual->anterior;
            }
            delete actual;
            return;
        }
        actual = actual->siguiente;
    }
}

template <typename T>
void ListaDoble<T>::Mostrar() {
    Nodo<T>* actual = cabeza;
    while (actual) {
        cout << actual->dato << endl;
        actual = actual->siguiente;
    }
}

template <typename T>
Nodo<T>* ListaDoble<T>::getCabeza() {
    return cabeza;
}

template <typename T>
Nodo<T>* ListaDoble<T>::getCola() {
    return cola;
}

template <typename T>
void ListaDoble<T>::Actualizar(T dato) {
    Nodo<T>* actual = cabeza;
    while (actual) {
        if (actual->dato == dato) {
            actual->dato = dato; // Actualizar el dato en el nodo actual
            return; // Terminamos la búsqueda después de la actualización
        }
        actual = actual->siguiente;
    }
}

#endif // LISTADOBLE_H
