#include "Validacion.h"

using namespace std;

string ingresarStringValidado() {
    string palabra;
    char c;

    while (true) {
        palabra.clear();
        while (true) {
            c = _getch();  // Captura la entrada sin mostrarla en pantalla

            if (c == 13) {  // Enter key
                break;
            }
            else if (c == 8) {  // Backspace key
                if (!palabra.empty()) {
                    palabra.pop_back();
                    cout << "\b \b";  // Borra el car�cter en la consola
                }
            }
            else if (isalpha(c)) {  // Solo acepta letras
                palabra.push_back(c);
                cout << c;  // Muestra el car�cter en la consola
            }
        }

        // Permitir que la palabra est� vac�a para aceptar el Enter sin caracteres
        break;
    }

    cout << endl;  // Nueva l�nea despu�s de la entrada
    return palabra;
}

int ingresarEntero() {
    string numero;
    bool valido = false;
    while (!valido) {
        try {
            char c;
            while (true) {
                c = _getch();
                if (c == '\r') {
                    cout << endl;
                    break;
                }
                else if (c == '\b') {
                    if (!numero.empty()) {
                        numero.pop_back();
                        cout << "\b \b";
                    }
                }
                else if (isdigit(c)) {
                    numero += c;
                    cout << c;
                }
            }
            valido = validarEntero(numero);
            if (!valido) {
                throw numero;
            }
        }
        catch (string e) {
            cout << "\nEl numero " << e << " no es valido" << endl;
            numero.clear();
            valido = false;
        }
    }
    return atoi(numero.c_str());
}

string ingresarLetra() {
    string palabra;
    char c;

    while (true) {
        palabra.clear();
        while (true) {
            c = _getch();  // Captura la entrada sin mostrarla en pantalla

            if (c == 13) {  // Enter key
                break;
            }
            else if (c == 8) {  // Backspace key
                if (!palabra.empty()) {
                    palabra.pop_back();
                    cout << "\b \b";  // Borra el car�cter en la consola
                }
            }
            else if (isalpha(c)) {  // Solo acepta letras
                palabra.push_back(c);
                cout << c;  // Muestra el car�cter en la consola
            }
        }

        if (!palabra.empty()) {
            break;
        }
        else {
            cout << "\nNo se permiten cadenas vacias. Intente de nuevo: ";
        }
    }

    cout << endl;  // Nueva l�nea despu�s de la entrada
    return palabra;
}

bool validar(string numero) {
    int inicio = 0;
    if (numero.length() == 0) {
        return false;
    }
    if (numero[0] == '+' || numero[0] == '-') {
        inicio = 1;
        if (numero.length() == 1) {
            return false;
        }
    }
    for (int i = inicio; i < numero.length(); i++) {
        if (!isdigit(numero[i]) && numero[i] != '.') {
            return false;
        }
    }
    return true;
}

bool validarEntero(string numero) {
    int inicio = 0;
    if (numero.length() == 0) {
        return false;
    }
    if (numero[0] == '+' || numero[0] == '-') {
        inicio = 1;
        if (numero.length() == 1) {
            return false;
        }
    }
    for (int i = inicio; i < numero.length(); i++) {
        if (!isdigit(numero[i])) {
            return false;
        }
    }
    return true;
}

bool validarLetra(string palabra) {
    char c;
    for (int i = 0; i < palabra.size(); i++) {
        c = palabra[i];
        if (isalpha(c) == 0) {
            if (isspace(c) == 0) {
                return 0;
            }
        }
    }
    return 1;
}

bool validarCedula(string cedula) {
    if (cedula.length() != 10) {
        return false;
    }
    int sum = 0;
    for (int i = 0; i < 9; i++) {
        int digit = cedula[i] - '0';
        if (i % 2 == 0) {
            digit *= 2;
            if (digit > 9) {
                digit -= 9;
            }
        }
        sum += digit;
    }
    int verifier = cedula[9] - '0';
    return (sum % 10 == 0) ? (verifier == 0) : ((10 - (sum % 10)) == verifier);
}

string ingresarCedula() {
    string cedula;
    char c;
    //cout << "Ingrese la cedula: ";
    while (true) {
        cedula = "";
        while (true) {
            c = _getch();
            if (c == 13) break;  // Enter
            if (c == 8) {        // Backspace
                if (!cedula.empty()) {
                    cedula.pop_back();
                    cout << "\b \b";
                }
            }
            else if (isdigit(c)) {
                cedula.push_back(c);
                cout << c;
            }
        }
        cout << endl;
        if (validarCedula(cedula)) {
            break;
        }
        else {
            cout << "Cedula invalida. Intente de nuevo." << endl;
        }
    }
    return cedula;
}

char* ingresar(char* msj) {
    static char dato[25];
    char c;
    int i = 0;
    printf("%s: ", msj);
    while ((c = _getch()) != 13) {
        if (isdigit(c) || c == 8) {  // 8 is the ASCII code for Backspace
            dato[i++] = c;
            printf("%c", c);
        }
    }
    dato[i] = '\0';
    return dato;
}

int ingresarEntero4() {
    string numero;
    bool valido = false;
    while (!valido) {
        try {
            char c;
            while (true) {
                c = _getch();
                if (c == '\r') {  // Si presiona Enter
                    cout << endl;
                    break;
                }
                else if (c == '\b') {  // Si presiona Retroceso
                    if (!numero.empty()) {
                        numero.pop_back();
                        cout << "\b \b";
                    }
                }
                else if (isdigit(c)) {  
                    if (numero.length() < 4) {  
                        numero += c;
                        cout << c;
                    }
                }
            }
            valido = validarEntero(numero);
            if (!valido) {
                throw numero;
            }
        }
        catch (string e) {
            cout << "\nEl numero " << e << " no es valido" << endl;
            numero.clear();
            valido = false;
        }
    }
    return atoi(numero.c_str());
}

Pila convertirCedulaAPila(const string& cedula) {
    Pila pila;
    for (char c : cedula) {
        pila.push(c - '0');
    }
    return pila;
}

//Validaciones para la fecha
// validar dia 1, 31
bool validarDia(int dia){
    return (dia>= 1 && dia<= 31);
}
// validar mes 1, 12
bool validarMes(int mes){
    return (mes>= 1 && mes<= 12);
}

int validarDia() {
    while (true) {
        char entrada[3] = {0}; // Inicializa el arreglo con ceros
        int i = 0;
        
        //std::cout << "Ingrese el dia (1-31): ";
        
        while (true) {
            char tecla = std::cin.get(); // Lee un carácter de la entrada estándar
            
            if (tecla == '\n') { // Fin de la entrada
                if (i > 0) { 
                    break;
                }
            } else if (tecla == '\b' && i > 0) { // Manejo del retroceso
                i--;
                std::cout << "\b \b";
                entrada[i] = '\0'; // Elimina el carácter
            } else if (i < 2 && std::isdigit(tecla)) { 
                entrada[i++] = tecla;
                std::cout << tecla;
            }
        }
        
        entrada[i] = '\0'; 
        
        int dia = std::atoi(entrada);
        
        if (validarDia(dia)) {
            return dia;
        }
        
        std::cout << "\nDia no permitido. Intente nuevamente: ";
    }
}


int validarMes() {
    while (true) {
        char entrada[3] = {0}; // Inicializa el arreglo con ceros
        int i = 0;
        
        //std::cout << "Ingrese el día (1-31): ";
        
        while (true) {
            char tecla = std::cin.get(); // Lee un carácter de la entrada estándar
            
            if (tecla == '\n') { 
                if (i > 0) { 
                    break;
                }
            } else if (tecla == '\b' && i > 0) { 
                i--;
                std::cout << "\b \b";
                entrada[i] = '\0'; 
            } else if (i < 2 && std::isdigit(tecla)) { 
                entrada[i++] = tecla;
                std::cout << tecla;
            }
        }
        
        entrada[i] = '\0';
        
        int mes = std::atoi(entrada);
        
        if (validarMes(mes)) {
            return mes;
        }
        
        std::cout << "\nMes no permitido. Intente nuevamente: ";
    }
}


bool esFinDeSemana(int dia, int mes, int anio) {
    tm fecha = {};
    fecha.tm_mday = dia;
    fecha.tm_mon = mes - 1;
    fecha.tm_year = anio - 1900;
    mktime(&fecha);

    // 0 -> Domingo, 6 -> Sabado
    return (fecha.tm_wday == 0 || fecha.tm_wday == 6);
}

