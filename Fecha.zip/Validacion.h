#pragma once

#include"Pila.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <cctype>
#include <conio.h>
#include <ctime>
#include <set>

using namespace std;


string ingresarStringValidado();
int ingresarEntero();
string ingresarLetra();
bool validar(string numero);
bool validarEntero(string numero);
bool validarLetra(string palabra);
bool validarCedula(string cedula);
string ingresarCedula();
char* ingresar(char* msj);
int ingresarEntero4();
Pila convertirCedulaAPila(const string& cedula);

bool validarDia(int dia);
bool validarMes(int mes);
int validarDia();
int validarMes();
//bool esFeriado(int dia, int mes);
bool esFinDeSemana(int dia, int mes, int anio);
